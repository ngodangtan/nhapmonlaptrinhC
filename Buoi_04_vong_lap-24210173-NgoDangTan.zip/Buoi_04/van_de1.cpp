#include <iostream>
using namespace std;

int main()
{
    for(int i = 1; i <= 3; i = i + 1)
    {
        cout << "Hay hoc C/C++ that tot" << endl;
    }

    return 0;
}