#include <iostream>
using namespace std;

int main() {
    int i = 1;
    while(i <= 6) {
        cout << "Phai hoc c++ that tot" << endl;
        i++;
    }
    return 0;
}