#include <iostream>
using namespace std;

int main()
{
    int n;
    do {
        cout << "Nhap n = ";
        cin >> n;
    } while (n < 0);

    cout << "Gia tri n =" << endl;
    return 0;
}
