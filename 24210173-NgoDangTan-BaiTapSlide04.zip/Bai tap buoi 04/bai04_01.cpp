#include <iostream>
using namespace std;

int main() {
    int n;
    for(int i = 2020; i <= 3838; i++) {
        if(i%2==0){
            printf("%d", i);
        }
    }
    return 0;
}