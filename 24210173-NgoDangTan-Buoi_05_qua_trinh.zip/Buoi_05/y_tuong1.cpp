#include <iostream>
using namespace std;

int main()
{
    int x = abs(-9);
    cout << x << endl;
    float y = pow(x, 3);
    cout << y << endl;
    //myfunc(x, y);
    return 0;
}