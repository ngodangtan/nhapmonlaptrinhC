//
// Created by Felix Ngo on 1/12/24.
//

#include <iostream>
using namespace std;

struct NhanVien{
  int maNV;
  char hoTen[100];
  float luongCoBan;
  int soNgayLam;
  float luongHangThang;
};

// Bai tap ve
// 1 Viet ham nhap du cho kieu du lieu NhanVien
// 2 Viet ham kieu nhan vien

int main() {
  int x;
  NhanVien nv;

  int arr_x[100];
  NhanVien arr_nv[100];
  return 0;
}